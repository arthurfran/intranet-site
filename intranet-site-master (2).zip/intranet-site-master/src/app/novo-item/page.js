// Página: /src/app/novo-item/page.tsx
'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NovoItemPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    nome: "",
    uf: "",
    local: "",
    quantidade: 0,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: name === 'quantidade' ? Number(value) : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch("/api/novo-item", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    router.push("/");
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Cadastrar Novo Item</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-md">
        <input name="nome" placeholder="Nome" onChange={handleChange} className="border p-2" />
        <input name="uf" placeholder="Unidade" onChange={handleChange} className="border p-2" />
        <input name="local" placeholder="Local" onChange={handleChange} className="border p-2" />
        <input name="quantidade" type="number" placeholder="Quantidade" onChange={handleChange} className="border p-2" />
        <button type="submit" className="bg-blue-600 text-white p-2">Salvar</button>
      </form>
    </div>
  );
}