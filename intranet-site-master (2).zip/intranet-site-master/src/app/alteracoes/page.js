import { PrismaClient } from "@prisma/client";
import React from "react";

const prisma = new PrismaClient();

function tipoBadge(tipo) {
  const cores = {
    "entrada": "background-color: #d1fae5; color: #065f46;",
    "saída": "background-color: #fee2e2; color: #991b1b;",
    "criação": "background-color: #dbeafe; color: #1e40af;",
  };
  return (
    <span
      style={{
        padding: "0.25rem 0.5rem",
        borderRadius: "0.25rem",
        fontSize: "0.875rem",
        fontWeight: "bold",
        ...(tipo in cores ? { ...parseStyle(cores[tipo]) } : {}),
      }}
    >
      {tipo}
    </span>
  );
}

function parseStyle(styleString) {
  return styleString.split(";").reduce((acc, rule) => {
    const [key, value] = rule.split(":");
    if (key && value) acc[key.trim()] = value.trim();
    return acc;
  }, {});
}

export default async function AlteracoesPage() {
  const alteracoes = await prisma.alteracao.findMany({
    include: { item: true },
    orderBy: { data: "desc" },
  });

  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ marginBottom: "1rem" }}>Histórico de Alterações</h1>

      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", minWidth: "600px" }}>
          <thead>
            <tr>
              <th style={{ border: "1px solid #ccc", padding: "0.5rem" }}>Item</th>
              <th style={{ border: "1px solid #ccc", padding: "0.5rem" }}>Tipo</th>
              <th style={{ border: "1px solid #ccc", padding: "0.5rem" }}>Data</th>
              <th style={{ border: "1px solid #ccc", padding: "0.5rem" }}>Quantidade</th>
            </tr>
          </thead>
          <tbody>
            {alteracoes.map((a) => {
              const quantidadeAnterior = a.dadosAnteriores?.quantidade ?? 0;
              const quantidadeNova = a.dadosNovos?.quantidade ?? 0;
              const diferenca = quantidadeNova - quantidadeAnterior;
              const simbolo = diferenca >= 0 ? "+" : "";
              const dataFormatada = new Date(a.data).toLocaleDateString();
              return (
                <tr key={a.id}>
                  <td style={{ border: "1px solid #ccc", padding: "0.5rem" }}>{a.item.nome}</td>
                  <td style={{ border: "1px solid #ccc", padding: "0.5rem" }}>{tipoBadge(a.tipoAlteracao)}</td>
                  <td style={{ border: "1px solid #ccc", padding: "0.5rem" }}>{dataFormatada}</td>
                  <td style={{ border: "1px solid #ccc", padding: "0.5rem", textAlign: "center" }}>{simbolo}{diferenca}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </main>
  );
}
