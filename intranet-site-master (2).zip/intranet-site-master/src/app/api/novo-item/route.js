// API: /src/app/api/novo-item/route.ts
import { PrismaClient } from "@prisma/client";
import { NextResponse } from "next/server";

const prisma = new PrismaClient();

export async function POST(req) {
  const data = await req.json();
  const item = await prisma.item.create({ data });
  await prisma.alteracao.create({
    data: {
      itemId: item.id,
      tipoAlteracao: "criação",
      dadosNovos: item,
    },
  });
  return NextResponse.json({ success: true });
} 