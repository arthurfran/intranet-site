import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  await prisma.item.createMany({
    data: [
      // Itens - Convés 1
      { nome: "pá galvanizada", uf: "UN", local: "Convés 1", quantidade: 26 },
      { nome: "rodo de madeira", uf: "un", local: "Convés 1", quantidade: 1 },
      { nome: "balde 15L", uf: "un", local: "Convés 1", quantidade: 1 },
      { nome: "agua sanitária", uf: "BB", local: "Convés 1", quantidade: 8 },
      { nome: "água sanitária", uf: "L", local: "Convés 1", quantidade: 89 },
      { nome: "saco de lixo 100L", uf: "fr", local: "Convés 1", quantidade: 2 },
      { nome: "saco de lixo 30L", uf: "fr", local: "Convés 1", quantidade: 1 },
      { nome: "Saco de lixo 40L", uf: "fr", local: "Convés 1", quantidade: 60 },
      { nome: "desinfetante", uf: "L", local: "Convés 1", quantidade: 190 },
      { nome: "alcool em gel", uf: "un", local: "Convés 1", quantidade: 41 },
      { nome: "desodorizador aerosol", uf: "un", local: "Convés 1", quantidade: 7 },
      { nome: "removedor de cera", uf: "BB", local: "Convés 1", quantidade: 2 },
      { nome: "cera cordex", uf: "BB", local: "Convés 1", quantidade: 21 },
      { nome: "sabonete líquido", uf: "L", local: "Convés 1", quantidade: 5 },
      { nome: "esponja", uf: "un", local: "Convés 1", quantidade: 39 },

      // Itens - Convés 2
      { nome: "cabeça vass pelo org", uf: "un", local: "Convés 2", quantidade: 12 },
      { nome: "cabeça vass pelo simtetico", uf: "un", local: "Convés 2", quantidade: 16 },
      { nome: "detergente", uf: "un", local: "Convés 2", quantidade: 52 },
      { nome: "papel toalha", uf: "pct", local: "Convés 2", quantidade: 11 },
      { nome: "trapos", uf: "un", local: "Convés 2", quantidade: 106 },
      { nome: "flanela laranja", uf: "un", local: "Convés 2", quantidade: 48 },
      { nome: "papel higiênico", uf: "FR", local: "Convés 2", quantidade: 20 },

      // Itens - Material de Expediente
      { nome: "almofada pra carimbo azul", uf: "un", local: "Material de Expediente", quantidade: 6 },
      { nome: "almofada pra carimbo s tinta", uf: "un", local: "Material de Expediente", quantidade: 5 },
      { nome: "apontador metálico", uf: "un", local: "Material de Expediente", quantidade: 13 },
      { nome: "bobinas pra calculadora", uf: "un", local: "Material de Expediente", quantidade: 22 },
      { nome: "borracha azul/preta", uf: "un", local: "Material de Expediente", quantidade: 28 },
      { nome: "cadeado 30mm", uf: "un", local: "Material de Expediente", quantidade: 1 },
      { nome: "caneta esferográfica azul", uf: "un", local: "Material de Expediente", quantidade: 55 },
      { nome: "caneta esferográfica preta", uf: "un", local: "Material de Expediente", quantidade: 162 },
      { nome: "caneta quadro branco azul", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "clipes  de papel n1", uf: "cx", local: "Material de Expediente", quantidade: 96 },
      { nome: "clipes  de papel n6", uf: "cx", local: "Material de Expediente", quantidade: 38 },
      { nome: "clipes de papel n2", uf: "cx", local: "Material de Expediente", quantidade: 41 },
      { nome: "cola bastão", uf: "un", local: "Material de Expediente", quantidade: 21 },
      { nome: "cola branca 40g", uf: "un", local: "Material de Expediente", quantidade: 49 },
      { nome: "corretivo líquido", uf: "un", local: "Material de Expediente", quantidade: 3 },
      { nome: "dermatografico amarelo", uf: "un", local: "Material de Expediente", quantidade: 14 },
      { nome: "dermatografico azul", uf: "un", local: "Material de Expediente", quantidade: 39 },
      { nome: "dermatográfico branco", uf: "un", local: "Material de Expediente", quantidade: 10 },
      { nome: "dermatografico preto", uf: "un", local: "Material de Expediente", quantidade: 28 },
      { nome: "dermatografico verde", uf: "un", local: "Material de Expediente", quantidade: 15 },
      { nome: "dermatografico vermelho", uf: "un", local: "Material de Expediente", quantidade: 35 },
      { nome: "dermatografico vinho", uf: "un", local: "Material de Expediente", quantidade: 7 },
      { nome: "durex 12mmx30M", uf: "un", local: "Material de Expediente", quantidade: 17 },
      { nome: "durex 45mm X40M (grande)", uf: "un", local: "Material de Expediente", quantidade: 40 },
      { nome: "envelope  pequeno", uf: "un", local: "Material de Expediente", quantidade: 1200 },
      { nome: "envelope 250x353 A4", uf: "un", local: "Material de Expediente", quantidade: 400 },
      { nome: "envelope 325x450", uf: "un", local: "Material de Expediente", quantidade: 690 },
      { nome: "extrator pra grampo", uf: "un", local: "Material de Expediente", quantidade: 9 },
      { nome: "Filtro flex flow libell", uf: "un", local: "Material de Expediente", quantidade: 30 },
      { nome: "filtro soft", uf: "un", local: "Material de Expediente", quantidade: 29 },
      { nome: "fita  corretiva", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "fita crepe", uf: "un", local: "Material de Expediente", quantidade: 54 },
      { nome: "fita crepe grande", uf: "un", local: "Material de Expediente", quantidade: 36 },
      { nome: "fita dupla face", uf: "un", local: "Material de Expediente", quantidade: 31 },
      { nome: "fita isolante 19x10m", uf: "un", local: "Material de Expediente", quantidade: 16 },
      { nome: "fita isolante 19x20m", uf: "un", local: "Material de Expediente", quantidade: 39 },
      { nome: "formulário contínuo", uf: "un", local: "Material de Expediente", quantidade: 1 },
      { nome: "grampeador", uf: "un", local: "Material de Expediente", quantidade: 16 },
      { nome: "grampo 26/6  galvanizado 5000", uf: "cx", local: "Material de Expediente", quantidade: 1 },
      { nome: "grampo 26/6 cobreado 5000", uf: "cx", local: "Material de Expediente", quantidade: 9 },
      { nome: "lacre", uf: "pc", local: "Material de Expediente", quantidade: 14 },
      { nome: "lápis preto", uf: "un", local: "Material de Expediente", quantidade: 519 },
      { nome: "livro de licenciado", uf: "un", local: "Material de Expediente", quantidade: 15 },
      { nome: "livro de portaló", uf: "un", local: "Material de Expediente", quantidade: 5 },
      { nome: "livro preto pautado e numerados", uf: "un", local: "Material de Expediente", quantidade: 28 },
      { nome: "marca texto amarelo", uf: "un", local: "Material de Expediente", quantidade: 2 },
      { nome: "marca texto verde", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "marcador permanente azul", uf: "un", local: "Material de Expediente", quantidade: 12 },
      { nome: "marcador permanente preto", uf: "un", local: "Material de Expediente", quantidade: 7 },
      { nome: "papel carbono", uf: "un", local: "Material de Expediente", quantidade: 33 },
      { nome: "pasta box", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "pasta preta", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "pasta suspensa com presilha", uf: "un", local: "Material de Expediente", quantidade: 28 },
      { nome: "pilha tipo aaa", uf: "un", local: "Material de Expediente", quantidade: 124 },
      { nome: "pilha tipo c (2un)", uf: "un", local: "Material de Expediente", quantidade: 44 },
      { nome: "pilha tipo d", uf: "un", local: "Material de Expediente", quantidade: 2 },
      { nome: "post it", uf: "pc com 4", local: "Material de Expediente", quantidade: 7 },
      { nome: "prendedor de papel 32 mm", uf: "un", local: "Material de Expediente", quantidade: 38 },
      { nome: "refil de tinta de impressora azul", uf: "un", local: "Material de Expediente", quantidade: 1 },
      { nome: "régua de plástico", uf: "un", local: "Material de Expediente", quantidade: 9 },
      { nome: "rendedor de papel 42mm", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "resma de papel A4", uf: "un", local: "Material de Expediente", quantidade: 49 },
      { nome: "Silver tape g", uf: "un", local: "Material de Expediente", quantidade: 36 },
      { nome: "silver tape p", uf: "un", local: "Material de Expediente", quantidade: 24 },
      { nome: "tesoura preta grande", uf: "un", local: "Material de Expediente", quantidade: 7 },
      { nome: "tinha pra carimbo preta", uf: "un", local: "Material de Expediente", quantidade: 4 },
      { nome: "tinha pra carimbo violeta", uf: "un", local: "Material de Expediente", quantidade: 12 },
      { nome: "toner fast printer", uf: "un", local: "Material de Expediente", quantidade: 5 },
      { nome: "toner profit", uf: "un", local: "Material de Expediente", quantidade: 2 },
    ],
  });

  console.log("✅ Itens adicionados com sucesso!");
}

main()
  .catch((e) => {
    console.error("❌ Erro ao inserir os itens:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

